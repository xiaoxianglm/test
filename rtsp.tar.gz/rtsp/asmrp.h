#ifndef MY_ASMRP_H
#define MY_ASMRP_H

#define MAX_RULEMATCHES 16

int asmrp_match (const char *rules, int bandwidth, int *matches) ;

#endif /* MY_ASMRP_H */
