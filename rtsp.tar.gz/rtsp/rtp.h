
#ifndef MYRTP_H
#define MYRTP_H

int read_rtp_from_server(int fd, char *buffer, int length);

#endif /* MYRTP_H */
